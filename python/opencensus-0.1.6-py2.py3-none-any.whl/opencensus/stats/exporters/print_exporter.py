# Copyright 2018, OpenCensus Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import re
import os
import platform
from . import base
from opencensus.stats import aggregation
from opencensus.stats import measure
from datetime import datetime
from opencensus.common.transports import async

MAX_TIME_SERIES_PER_UPLOAD = 200
OPENCENSUS_TASK_DESCRIPTION = "Opencensus task identifier"
DEFAULT_DISPLAY_NAME_PREFIX = "OpenCensus"
ERROR_BLANK_PROJECT_ID = "expecting a non-blank ProjectID"
CONS_NAME = "name"
CONS_TIME_SERIES = "timeseries"
EPOCH_DATETIME = datetime(1970, 1, 1)
EPOCH_PATTERN = "%Y-%m-%dT%H:%M:%S.%fZ"


class PrintStatsExporter(base.StatsExporter):
    """ StackdriverStatsExporter exports stats
    to the Stackdriver Monitoring."""

    def __init__(self,
                 transport=async.AsyncTransport):
        self._transport = transport(self)

    def on_register_view(self, view):
        print "register "
        print str(view)
        print view.name
        print view.description
        print view.columns
        print view.measure
        print view.measure.name
        print view.measure.description
        print view.measure.unit
        print view.aggregation
        print view.aggregation.aggregation_type
        print view.aggregation.buckets
        print view.aggregation.boundaries
        print view.aggregation.distribution

    def emit(self, view_datas):
        """ export data to Stackdriver Monitoring"""
        if view_datas is not None:
            for view_data in view_datas:
                print(view_data)
                print(view_data.view)
                print(view_data.start_time)
                print(view_data.end_time)
                for data in view_data.tag_value_aggregation_data_map.items():
                    print(data)
                    dd = data[1]
                    print dd.mean_data
                    print dd.count_data
                    print dd.min
                    print dd.max

    def export(self, view_datas):
        """ export data to transport class"""
        if view_datas is not None:
            self._transport.export(view_datas)
